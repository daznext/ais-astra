#!/bin/sh
PATH=$PATH:/bin:/usr/bin:/sbin
case $1 in 
lock) my_dir=`ls -l /dev/disk/by-path/*usb* 2>/dev/null|sed 's%^.*/\([^/]*\)$%\1%'|fgrep -wf - /proc/mounts|cut -d' ' -f2|sed 's%\\\040% %g'|head -1`
    test -z "$my_dir" && exit 1
    echo "$my_dir"
    exit 0;;
unlock) test -d "$path" || `logger "cprocsp: The flash disk was unmounted while in use" && exit 0`
	exit 0;;
esac
#case $1 in 
#lock) flash=''
#      for dev in `mount|awk '{print $3}'|grep ^/`; do
#        fs=`/usr/sbin/fstyp $dev 2>/dev/null` && test $fs = "pcfs" && flash=$dev
#      done
#      if [ -n "$flash" ]; then
#        mount| grep $flash |awk '{print $1}'
#        exit 0
#      fi 
#;;
#unlock) test -d $path || exit 1 
#	exit 0;;
#esac
#case $1 in 
#lock) my_dir=`mount|fgrep -w  msdosfs|sed -e 's/[^[:blank:]]*[[:blank:]]//; s/[^[:blank:]]*[[:blank:]]//; s/[[:blank:]]([^(]*)[^()]*$//g'|head -1`
#    test -z "$my_dir" && exit 1
#    echo "$my_dir"
#    exit 0;;
#unlock) test -d $path || `logger "cprocps: The flash disk was unmounted while in use" && exit 0`
#	exit 0;;
#esac
#case $1 in
#lock) my_dir=`mount|fgrep -w  msdos|sed -e 's/[^[:blank:]]*[[:blank:]]//; s/[^[:blank:]]*[[:blank:]]//; s/[[:blank:]]([^(]*)[^()]*$//g'|head -1`
#    test -z "$my_dir" && exit 1
#    echo "$my_dir"
#    exit 0;;
#unlock) test -d $path || `logger "cprocps: The flash disk was unmounted while in use" && exit 0`
#  exit 0;;
#esac
exit 1
