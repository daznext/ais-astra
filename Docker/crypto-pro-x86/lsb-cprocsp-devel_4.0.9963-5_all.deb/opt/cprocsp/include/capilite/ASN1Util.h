#ifndef __ASN1_UTIL_H
#define __ASN1_UTIL_H
#undef min
#undef max

#include "asn1type.h"
#include "PKIXCMP.h"
#include "CPPKIXCMP.h"
#include "PKIX1Explicit88.h"
#include "CertificateExtensions.h"
#include "ASN1CGeneralizedTime.h"
#include "ASN1CUTCTime.h"
#include "ASN1Blob.h"
#ifdef _WIN32
#include <windows.h>
#include <WinCrypt.h>
#else
#include "CSP_WinCrypt.h"
#endif	/* _WIN32 */

#include <iostream>

using namespace asn1data;
class ctxt_handle
{
public:
    ctxt_handle() {}
    ~ctxt_handle() { release(); }

    bool init();
    ASN1CTXT* get() { return &ctxt_; }
    void release();
private:
    ctxt_handle( const ctxt_handle&);
    ctxt_handle& operator=( const ctxt_handle&);

    ASN1CTXT ctxt_;
};

std::string strip_white_space( const std::string &src );

void 
Serial2Blob( ASN1CTXT* pctxt, CACMPT_BLOB &dest, const char *serial );

ASN1T_Extension * ASN1T_Extensions_find_item(
    const ASN1T_Extensions& extensions, const ASN1TObjId &extnID );

const void* ASN1T_Extensions_find(
    const ASN1T_Extensions& extensions, const ASN1TObjId &extnID, 
    bool &critical );

void str1cpy( char *dest, const char *src, size_t len, const char*text );
void str1cpy( wchar_t *dest, const char *src, size_t len, const char*text );
void str1cpy8( wchar_t *dest, const ASN1UTF8String &src, size_t len, const char*text, ASN1CTXT *pctxt );
void str1cpy( char *dest, const ASN1OBJID &src, size_t len, const char*text );

int str2oid( const char *str, ASN1OBJID *oid );
ASN1OBJID str2oid( const char* str);

int oid2str( std::string& str, const ASN1OBJID *oid );

class CACMPT_ASN1BERDecodeBuffer : public ASN1BERDecodeBuffer {
public:
    CACMPT_ASN1BERDecodeBuffer (const ASN1OCTET* pMsgBuf, int msgBufLen)
	: ASN1BERDecodeBuffer (pMsgBuf, msgBufLen) {}
    CACMPT_ASN1BERDecodeBuffer (const CACMPT_BLOB &msgBuf)
	: ASN1BERDecodeBuffer (msgBuf.pbData, msgBuf.cbData) {}
    CACMPT_ASN1BERDecodeBuffer ()
	: ASN1BERDecodeBuffer () {}
    int setBuffer( const CACMPT_BLOB &src ) {
	mBufSetFlag = FALSE;
	return ASN1BERDecodeBuffer::setBuffer( (ASN1OCTET*)src.pbData, src.cbData );
    }
    int setBuffer( const BYTE *src, size_t len ) {
	mBufSetFlag = FALSE;
	return ASN1BERDecodeBuffer::setBuffer( src, static_cast<int>(len) );
    }
} ;

ASN1GeneralizedTime
ASN1GeneralizedTime_current (ASN1BEREncodeBuffer &enc_buffer);
ASN1UTCTime
ASN1UTCTime_current (ASN1BEREncodeBuffer &enc_buffer);
ASN1UTCTime
ASN1UTCTime_min (ASN1BEREncodeBuffer &enc_buffer, ASN1UTCTime a, ASN1UTCTime b);

ASN1ConstCharPtr
ASN1Time_set (
    ASN1BEREncodeBuffer &enc_buffer, 
    const ASN1CTime &gtime );

int compare_time( const ASN1T_Time &left, const ASN1CTime &right );
inline bool operator <= ( const ASN1T_Time &left, const ASN1CTime &right )
{ return compare_time( left, right ) <= 0; }
inline bool operator >= ( const ASN1T_Time &left, const ASN1CTime &right )
{ return compare_time( left, right ) >= 0; }
inline bool operator < ( const ASN1T_Time &left, const ASN1CTime &right )
{ return compare_time( left, right ) < 0; }
inline bool operator > ( const ASN1T_Time &left, const ASN1CTime &right )
{ return compare_time( left, right ) > 0; }
inline bool operator == ( const ASN1T_Time &left, const ASN1CTime &right )
{ return compare_time( left, right ) == 0; }
inline bool operator != ( const ASN1T_Time &left, const ASN1CTime &right )
{ return compare_time( left, right ) != 0; }

int compare_time( const ASN1T_Time& left, const ASN1T_Time& right );
inline bool operator <= ( const ASN1T_Time &left, const ASN1T_Time &right )
{ return compare_time( left, right ) <= 0; }
inline bool operator >= ( const ASN1T_Time &left, const ASN1T_Time &right )
{ return compare_time( left, right ) >= 0; }
inline bool operator < ( const ASN1T_Time &left, const ASN1T_Time &right )
{ return compare_time( left, right ) < 0; }
inline bool operator > ( const ASN1T_Time &left, const ASN1T_Time &right )
{ return compare_time( left, right ) > 0; }
inline bool operator == ( const ASN1T_Time &left, const ASN1T_Time &right )
{ return compare_time( left, right ) == 0; }
inline bool operator != ( const ASN1T_Time &left, const ASN1T_Time &right )
{ return compare_time( left, right ) != 0; }

ASN1T_AlgorithmIdentifier &
ASN1T_AlgorithmIdentifier_set (
    ASN1CTXT* pctxt,
    const char * oid,
    const BYTE * pbParameters = 0,
    DWORD cbParameters = 0
    );

ASN1T_AlgorithmIdentifier &
ASN1T_AlgorithmIdentifier_set (
    ASN1CTXT* pctxt,
    const char * oid,
    const CACMPT_BLOB * parameters
    );

void
ASN1T_AlgorithmIdentifier_get (
    CACMPT_AlgorithmIdentifier& dest,
    const ASN1T_AlgorithmIdentifier& src
    );

ASN1T_AlgorithmIdentifier&
ASN1T_AlgorithmIdentifier_set (
    ASN1CTXT* pctxt,
    HCRYPTPROV hProv,
    DWORD dwKeySpec
    );

ASN1T_KeyIdentifier&
ASN1T_KeyIdentifier_set (
    HCRYPTPROV hProv,
    ASN1CTXT* pctxt,
    ASN1TDynBitStr& subjectPublicKey
    );

/* мутный набор, боязно причёсывать */
std::string SmallBitStringToString( const unsigned *set, 
    const char **strings, size_t length, unsigned src );
std::wstring SmallBitStringToWString( const unsigned *set,
    const wchar_t **strings, size_t length, unsigned src );
unsigned SmallBitStringFromString( const unsigned *set, 
    const char **strings, size_t length, const char *str,
    const char *zero = NULL );

/* и этих боязно */
std::string tostring( const wchar_t* );
std::wstring towstring( const char* );
inline std::string tostring( const std::wstring &src )
{ return tostring( src.c_str() ); }
inline std::wstring towstring( const std::string &src )
{ return towstring( src.c_str() ); }
std::wstring towstring( int j );
inline std::ostream& operator<<( std::ostream &o, const wchar_t *src )
{ return o << tostring( src ).c_str(); }

void fillIssuerAndSerialNumber(
    ASN1CTXT* pctxt,
    ASN1T_IssuerAndSerialNumber** ppIssuerAndSerialNumber,
    const CERT_NAME_BLOB& msIssuer,
    const CRYPT_INTEGER_BLOB& msSerialNumber);

template<class ASN1_T>
ASN1_T* asn1New( ASN1CTXT* pctxt)
{
    ASN1_T* p = ALLOC_ASN1ELEM(pctxt,ASN1_T);
    if(!p)
	throw CA_MEMORY_EXCEPTION;
    return p;
}

template<class ASN1_T>
ASN1_T* asn1NewArray( ASN1CTXT* pctxt, size_t size)
{
    ASN1_T* p = ALLOC_ASN1ARRAY2(pctxt, size, ASN1_T);
    if(!p)
	throw CA_MEMORY_EXCEPTION;
    return p;
}

void
ASN1T_BigInt_set (CACMPT_SERIAL szSerial, ASN1OCTET* buf, int len);

void
ASN1T_BigInt_get (const CACMPT_SERIAL szSerial, ASN1OCTET* buf, int len);

void
ASN1T_BigInt_inc (ASN1OCTET* buf, int len, int start = 0);

CACMPT_BigInteger ASN1StringToBigInteger( const ASN1ConstCharPtr strBigInt);
ASN1ConstCharPtr BigIntegerToASN1String( ASN1CTXT* pctxt, const CACMPT_BigInteger& blob);
#endif // __ASN1_UTIL_H
