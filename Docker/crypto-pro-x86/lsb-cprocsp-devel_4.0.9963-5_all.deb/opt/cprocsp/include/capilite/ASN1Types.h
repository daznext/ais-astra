/*
 * Copyright(C) 2003 ������ ���
 *
 * ���� ���� �������� ����������, ����������
 * �������������� �������� ������ ���.
 *
 * ����� ����� ����� ����� �� ����� ���� �����������,
 * ����������, ���������� �� ������ �����,
 * ������������ ��� �������������� ����� ��������,
 * ���������������, �������� �� ���� � ��� ��
 * ����� ������������ ������� ��� ����������������
 * ���������� ���������� � ��������� ������ ���.
 */

/*!
 * \file $RCSfile$
 * \version $Revision: 154920 $
 * \date $Date:: 2017-04-04 14:11:58 +0300#$
 * \author $Author: dim $
 *
 * \brief ������ � ��������� ��� ASN1 �����.
 */

#ifndef _ASN1TYPES_H
#define _ASN1TYPES_H

#include "common.h"

#include <memory>
#include <vector>
#include <list>

#include "ASN1Blob.h"
#include "Date.h"

class CACMPT_GeneralNameImpl;
class CACMPT_GeneralName
{
public:
    enum Type
    {
//	t_otherName = 1,
	t_rfc822Name = 2,
	t_dNSName = 3,
//	t_x400Address = 4,
	t_directoryName = 5,
//	t_ediPartyName = 6,
	t_uniformResourceIdentifier = 7,
	t_iPAddress = 8,
	t_registeredID = 9
    };
public:
    CACMPT_GeneralName();
    ~CACMPT_GeneralName();

    CACMPT_GeneralName( const CACMPT_GeneralName& src);
    CACMPT_GeneralName& operator=( const CACMPT_GeneralName& src);

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);

    // get
    Type get_type() const;
    const std::string* get_rfc822Name() const;
    const std::string* get_dNSName() const;
    const CACMPT_BLOB* get_directoryName() const;
    const std::string* get_uniformResourceIdentifier() const;
    const CACMPT_BLOB* get_iPAddress() const;
    const CACMPT_OID* get_registeredID() const;
    // set
    void set_rfc822Name( const std::string& rfc822Name);
    void set_dNSName( const std::string& dNSName);
    void set_directoryName( const CACMPT_BLOB& directoryName);
    void set_uniformResourceIdentifier( 
	const std::string& uniformResourceIdentifier);
    void set_iPAddress( const CACMPT_BLOB& iPAddress);
    void set_registeredID( const CACMPT_OID& registeredID);
private:
    void clear();
    CACMPT_GeneralNameImpl* pImpl_;
};

bool operator==( const CACMPT_GeneralName& lhs, const CACMPT_GeneralName& rhs);
bool operator!=( const CACMPT_GeneralName& lhs, const CACMPT_GeneralName& rhs);

typedef std::list<CACMPT_GeneralName> CACMPT_GeneralNames;

// �������� �� ����������� � ASN1Traits.cpp
struct CACMPT_PolicyInformation
{
    CACMPT_OID policyIdentifier;
};

typedef std::vector<CACMPT_PolicyInformation> CACMPT_PolicyInformationList;

struct CACMPT_ContentInfo
{
    CACMPT_OID contentType;
    CACMPT_BLOB content;
};

struct CACMPT_IssuerSerial
{
    CACMPT_GeneralNames issuer;
    CACMPT_BigInteger serialNumber;
};

bool operator==( const CACMPT_IssuerSerial& lhs, const CACMPT_IssuerSerial& rhs);
bool operator!=( const CACMPT_IssuerSerial& lhs, const CACMPT_IssuerSerial& rhs);

class CACMPT_ESSCertID
{
public:
    static CACMPT_ESSCertID fromCetificate( const CACMPT_BLOB& certificate);
public:
    CACMPT_ESSCertID();
    CACMPT_ESSCertID( const CACMPT_BLOB& certHash);

    CACMPT_ESSCertID( const CACMPT_ESSCertID& src);
    CACMPT_ESSCertID& operator=( const CACMPT_ESSCertID& src);

    bool matches( const CACMPT_BLOB& certificate);

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);

    // get
    const CACMPT_BLOB& get_certHash() const;
    const CACMPT_IssuerSerial* get_issuerSerial() const;
    // set
    void set_certHash( const CACMPT_BLOB& certHash);
    void set_issuerSerial( const CACMPT_IssuerSerial* issuerSerial);
private:
    CACMPT_BLOB certHash_;
    std::auto_ptr<CACMPT_IssuerSerial> issuerSerial_;
};

bool operator==( const CACMPT_ESSCertID& lhs, const CACMPT_ESSCertID& rhs);
bool operator!=( const CACMPT_ESSCertID& lhs, const CACMPT_ESSCertID& rhs);

typedef std::vector<CACMPT_ESSCertID> CACMPT_ESSCertIDList;

struct CACMPT_OtherHashAlgAndValue
{
    CACMPT_OtherHashAlgAndValue() {};
    CACMPT_OtherHashAlgAndValue(
	const CACMPT_BLOB& _hashValue,
	const CACMPT_AlgorithmIdentifier& _hashAlgorithm)	
	: hashAlgorithm(_hashAlgorithm), hashValue(_hashValue) {}
    CACMPT_AlgorithmIdentifier hashAlgorithm;
    CACMPT_BLOB hashValue;
};

class CACMPT_OtherHashImpl;

class CACMPT_OtherHash
{
public:
    enum Type
    {
	t_sha1Hash = 1,
	t_otherHash = 2
    };
public:
    CACMPT_OtherHash();
    CACMPT_OtherHash( const CACMPT_BLOB& sha1Hash);
    CACMPT_OtherHash( const CACMPT_OtherHashAlgAndValue& otherHash);
    ~CACMPT_OtherHash();

    CACMPT_OtherHash( const CACMPT_OtherHash& src);
    CACMPT_OtherHash& operator=( const CACMPT_OtherHash& src);

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);

    // get
    Type get_type() const;
    const CACMPT_BLOB* get_sha1Hash() const;
    const CACMPT_OtherHashAlgAndValue* get_otherHash() const;
    // set
    void set_sha1Hash( const CACMPT_BLOB& sha1Hash);
    void set_otherHash( const CACMPT_OtherHashAlgAndValue& otherHash);
private:
    void clear();
    CACMPT_OtherHashImpl* pImpl_;
};

bool operator==( const CACMPT_OtherHash& lhs, const CACMPT_OtherHash& rhs);
bool operator!=( const CACMPT_OtherHash& lhs, const CACMPT_OtherHash& rhs);

class CACMPT_OtherCertID
{
public:
    static CACMPT_OtherCertID fromCetificate(
	const CACMPT_BLOB& certificate, 
	const CACMPT_AlgorithmIdentifier& hashAlgorithm);
public:
    CACMPT_OtherCertID();
    CACMPT_OtherCertID( const CACMPT_BLOB& sha1Hash);
    CACMPT_OtherCertID( 
	const CACMPT_BLOB& hashValue,
	const CACMPT_AlgorithmIdentifier& hashAlgorithm);

    CACMPT_OtherCertID( const CACMPT_OtherCertID& src);
    CACMPT_OtherCertID& operator=( const CACMPT_OtherCertID& src);

    bool matches( 
	const CACMPT_BLOB& certificate,
	const CACMPT_AlgorithmIdentifier& hashAlgorithm);

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);

    // get
    const CACMPT_OtherHash& get_otherCertHash() const;
    const CACMPT_IssuerSerial* get_issuerSerial() const;
    // set
    void set_otherCertHash( const CACMPT_OtherHash& otherCertHash);
    void set_issuerSerial( const CACMPT_IssuerSerial* issuerSerial);
private:
    CACMPT_OtherHash otherCertHash_;
    std::auto_ptr<CACMPT_IssuerSerial> issuerSerial_;
};

bool operator==( const CACMPT_OtherCertID& lhs, const CACMPT_OtherCertID& rhs);
bool operator!=( const CACMPT_OtherCertID& lhs, const CACMPT_OtherCertID& rhs);

typedef std::vector<CACMPT_OtherCertID> CACMPT_OtherCertIDList;

struct CACMPT_ReasonFlags
{
    static const unsigned unused; //(0)
    static const unsigned keyCompromise; //(1)
    static const unsigned caCompromise; //(2)
    static const unsigned affiliationChanged; //(3)
    static const unsigned superseded; //(4)
    static const unsigned cessationOfOperation; //(5)
    static const unsigned certificateHold; //(6)
    static const unsigned privilegeWithdrawn; //(7)
    static const unsigned aACompromise; //(8)

    static const unsigned sequence[9];
    unsigned value;
};

class CACMPT_DistributionPointNameImpl;

class CACMPT_DistributionPointName
{
public:
    enum Type
    {
	t_fullName = 1
    };
public:
    CACMPT_DistributionPointName();
    CACMPT_DistributionPointName( const CACMPT_GeneralNames& fullName);
    ~CACMPT_DistributionPointName();

    CACMPT_DistributionPointName( const CACMPT_DistributionPointName& src);
    CACMPT_DistributionPointName& operator=( const CACMPT_DistributionPointName& src);

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);

    // get
    Type get_type() const;
    const CACMPT_GeneralNames* get_fullName() const;
    // set
    void set_fullName( const CACMPT_GeneralNames& fullName);
private:
    void clear();
    CACMPT_DistributionPointNameImpl* pImpl_;
};

class CACMPT_DistributionPointImpl;

class CACMPT_DistributionPoint
{
public:
    CACMPT_DistributionPoint();
    ~CACMPT_DistributionPoint();

    CACMPT_DistributionPoint( const CACMPT_DistributionPoint& src);
    CACMPT_DistributionPoint& operator=( const CACMPT_DistributionPoint& src);

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);

    // get
    const CACMPT_DistributionPointName* get_distributionPoint() const;
    const CACMPT_ReasonFlags* get_reasons() const;
    const CACMPT_GeneralNames* get_cRLIssuer() const;
    // set
    void set_distributionPoint( 
	const CACMPT_DistributionPointName* distributionPoint);
    void set_reasons( const CACMPT_ReasonFlags* reasons);
    void set_cRLIssuer( const CACMPT_GeneralNames* cRLIssuer);
private:
    void clear();
    CACMPT_DistributionPointImpl* pImpl_;
};

CACMPT_BLOB toOctetString( const CACMPT_BLOB& blob);
CACMPT_BLOB fromOctetString( const CACMPT_BLOB& blob);

struct CACMPT_AccessDescription
{
    CACMPT_OID accessMethod;
    CACMPT_GeneralName accessLocation;
};

typedef std::list<CACMPT_AccessDescription> CACMPT_AuthorityInfoAccessSyntax;

class CACMPT_TimeChoiceImpl;

class CACMPT_TimeChoice
{
public:
    enum Type
    {
	t_utcTime = 1,
	t_generalTime = 2
    };
public:
    CACMPT_TimeChoice();
    CACMPT_TimeChoice( const CACMPT_Date& time);
    ~CACMPT_TimeChoice();

    CACMPT_TimeChoice( const CACMPT_TimeChoice& src);
    CACMPT_TimeChoice& operator=( const CACMPT_TimeChoice& src);

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);

    // get
    Type get_type() const;
    const CACMPT_Date& get_time() const;
    // set
    void set_time( const CACMPT_Date& time);
private:
    void clear();
    CACMPT_TimeChoiceImpl* pImpl_;
};

class CACMPT_AttrValue /* ������, ��� ������������ ������ � pkixcmp */
{    
  protected:
    std::string m_oid;
    CACMPT_BLOB m_der;
    CACMPT_AttrValue () {}
  public:
    CACMPT_AttrValue (const std::string& oid, const CACMPT_BLOB& der)
	: m_oid(oid), m_der(der) {}
    CACMPT_AttrValue (const CACMPT_AttrValue& src) 
	: m_oid (src.m_oid), m_der (src.m_der) {}
    CACMPT_AttrValue& operator= (const CACMPT_AttrValue& src)
    {
	if(this == &src)
	    return *this;
	m_oid = src.m_oid;
	m_der = src.m_der;
	return *this;
    }
    inline const std::string& get_oid () const { return m_oid; }
    inline const CACMPT_BLOB& get_der () const { return m_der; }
};

bool operator==( const CACMPT_AttrValue& lhs, const CACMPT_AttrValue& rhs);
bool operator!=( const CACMPT_AttrValue& lhs, const CACMPT_AttrValue& rhs);

extern const char sz_emailAddress[];
extern const char sz_id_at_commonName[];
extern const char sz_id_at_surname[];
extern const char sz_id_at_countryName[];
extern const char sz_id_at_localityName[];
extern const char sz_id_at_stateOrProvinceName[];
extern const char sz_id_at_organizationName[];
extern const char sz_id_at_organizationalUnitName[];
extern const char sz_id_at_title[];
extern const char sz_id_at_givenName[];
extern const char sz_id_at_initials[];
extern const char sz_id_at_pseudonym[];

extern const char sz_id_aa_signingCertificate[];

class CACMPT_AttrSigningCertificate: public CACMPT_AttrValue
{
public:
    CACMPT_AttrSigningCertificate() {}
    CACMPT_AttrSigningCertificate( const CACMPT_BLOB& der)
    : CACMPT_AttrValue(sz_id_aa_signingCertificate,der) { decode(); }
    CACMPT_AttrSigningCertificate( const CACMPT_ESSCertIDList& certs);

    void encode();
    void decode();

    // get
    const CACMPT_ESSCertIDList& get_certs() const;
    const CACMPT_PolicyInformationList* get_policies() const;
    // set
    void set_certs( const CACMPT_ESSCertIDList& certs);
    void set_policies( const CACMPT_PolicyInformationList* policies);
private:
    CACMPT_ESSCertIDList certs_;
    std::auto_ptr<CACMPT_PolicyInformationList> policies_;
};

extern const char sz_id_aa_ets_otherSigCert[];

class CACMPT_AttrOtherSigningCertificate: public CACMPT_AttrValue
{
public:
    CACMPT_AttrOtherSigningCertificate() {}
    CACMPT_AttrOtherSigningCertificate( const CACMPT_BLOB& der)
    : CACMPT_AttrValue(sz_id_aa_ets_otherSigCert,der) { decode(); }
    CACMPT_AttrOtherSigningCertificate( const CACMPT_OtherCertIDList& certs);

    void encode();
    void decode();

    // get
    const CACMPT_OtherCertIDList& get_certs() const;
    const CACMPT_PolicyInformationList* get_policies() const;
    // set
    void set_certs( const CACMPT_OtherCertIDList& certs);
    void set_policies( const CACMPT_PolicyInformationList* policies);
private:
    CACMPT_OtherCertIDList certs_;
    std::auto_ptr<CACMPT_PolicyInformationList> policies_;
};

extern const char sz_id_contentType[];

class CACMPT_AttrContentType: public CACMPT_AttrValue
{
public:
    CACMPT_AttrContentType( const CACMPT_OID& contentType)
	: CACMPT_AttrValue(sz_id_contentType,CACMPT_BLOB()),
	  contentType_(contentType)
    { encode(); }
    CACMPT_AttrContentType( const CACMPT_BLOB& der)
	: CACMPT_AttrValue(sz_id_contentType,der)
    { decode(); }

    void encode();
    void decode();

    CACMPT_OID get_contentType() const { return contentType_; }
    void set_contentType( const CACMPT_OID& contentType) 
    { contentType_ = contentType; encode(); }
private:
    CACMPT_OID contentType_;
};

extern const char sz_id_messageDigest[];

class CACMPT_AttrMessageDigest: public CACMPT_AttrValue
{
public:
    CACMPT_AttrMessageDigest()
	: CACMPT_AttrValue(sz_id_messageDigest,CACMPT_BLOB())
    { }
    CACMPT_AttrMessageDigest( const CACMPT_BLOB& der)
	: CACMPT_AttrValue(sz_id_messageDigest,der)
    { decode(); }

    void encode();
    void decode();

    const CACMPT_BLOB& get_messageDigest() const { return messageDigest_; }
    void set_messageDigest( const CACMPT_BLOB& messageDigest) 
    { messageDigest_ = messageDigest; encode(); }
private:
    CACMPT_BLOB messageDigest_;
};

class CACMPT_Attribute
{
  public:
    typedef std::list<CACMPT_AttrValue> ValueList;
    typedef ValueList::iterator value_iterator;
    typedef ValueList::const_iterator const_value_iterator;
  protected:
    std::list<CACMPT_AttrValue> m_values;
    std::string m_oid;
  public:
    CACMPT_Attribute () { }
    CACMPT_Attribute (const char *oid)
	: m_oid (oid) { }
    CACMPT_Attribute (const std::string& oid)
	: m_oid (oid) { }
    CACMPT_Attribute (const CACMPT_Attribute& src)
	: m_values (src.m_values), m_oid (src.m_oid) {}
    CACMPT_Attribute& operator=( const CACMPT_Attribute& src)
    { m_oid = src.m_oid; m_values = src.m_values; return *this; }
    inline const std::string& get_oid () const { return m_oid; }
    inline const_value_iterator begin() const { return m_values.begin(); }
    inline const_value_iterator end() const { return m_values.end(); }
    inline value_iterator begin() { return m_values.begin(); }
    inline value_iterator end() { return m_values.end(); }
    void add( const CACMPT_BLOB& der)
    { m_values.push_back( CACMPT_AttrValue(m_oid,der) ); }
    void add( const CACMPT_AttrValue& value)
    { m_values.push_back( value ); }
    value_iterator erase( value_iterator pos)
    { return m_values.erase(pos); }
    size_t size() const
    { return m_values.size(); }

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);

    friend bool operator==( const CACMPT_Attribute& lhs, const CACMPT_Attribute& rhs);
};

bool operator==( const CACMPT_Attribute& lhs, const CACMPT_Attribute& rhs);
bool operator!=( const CACMPT_Attribute& lhs, const CACMPT_Attribute& rhs);

class CACMPT_Attributes : public std::list<CACMPT_Attribute>
{
public:
    typedef std::list<CACMPT_Attribute> AttrList;
    CACMPT_Attributes() : AttrList() {}
    CACMPT_Attributes( const_iterator f, const_iterator l ) : 
	AttrList(f,l) {}
    ~CACMPT_Attributes(){}
    void Delete (const std::string& oid);
    void Insert (CACMPT_Attribute ext);
    iterator find( std::string oid )
    {	iterator e = end();
	for( iterator i = begin(); i != e; i++ ) 
	{ if( i->get_oid() == oid ) return i; } 
	return e;
    }
    const_iterator find( std::string oid ) const
    {	const_iterator e = end();
	for( const_iterator i = begin(); i != e; i++ ) 
	{ if( i->get_oid() == oid ) return i; }
	return e;
    }

    CACMPT_BLOB encode() const;
    void decode( const CACMPT_BLOB& encoded);
};

CACMPT_Attributes CRYPTToCACMPTAttributes(PCRYPT_ATTRIBUTES pAttrs);

void date1cpy( CACMPT_Date &out_date, const char *in_date, int format = CACMPT_TimeChoice::t_utcTime );

CACMPT_BigInteger StringToBigInteger( const std::string& strBigInt);
std::string BigIntegerToString( const CACMPT_BigInteger& blob);

enum CACMPT_StringType
{
    stDefault,
    stUTF8String,
    stPrintableString,
    stTeletexString,
    stBMPString,
    stIA5String,
    stUniversalString,
    stNumericString
};

class CACMPT_AttributeTypeAndValue
{
public:
    CACMPT_AttributeTypeAndValue();
    CACMPT_AttributeTypeAndValue( const CACMPT_AttrValue& attrValue);
    CACMPT_AttributeTypeAndValue( const CACMPT_OID& type, const CACMPT_BLOB& value);
    CACMPT_AttributeTypeAndValue( 
	const std::wstring& type, const std::wstring& value,
        size_t &pos, CACMPT_StringType stringType = stDefault,
        DWORD dwStrType = 0);
    CACMPT_AttributeTypeAndValue( 
	const std::wstring& str, size_t& pos,
        CACMPT_StringType stringType = stDefault, DWORD dwStrType = 0);
    CACMPT_AttributeTypeAndValue( const CACMPT_AttributeTypeAndValue& src);
    CACMPT_AttributeTypeAndValue& operator=( const CACMPT_AttributeTypeAndValue& src);
    CACMPT_OID get_type() const;
    std::wstring get_type_str(DWORD dwStrType = CERT_X500_NAME_STR|CERT_NAME_STR_NO_QUOTING_FLAG) const;
    CACMPT_BLOB get_value() const;
    std::wstring get_value_str(DWORD dwStrType = CERT_X500_NAME_STR|CERT_NAME_STR_NO_QUOTING_FLAG) const;

    void set_type( const CACMPT_OID& type);
    void set_type_str( const std::wstring& type);
    void set_value( const CACMPT_BLOB& value);
    void set_value_str(
	const std::wstring& value, 
	CACMPT_StringType stringType = stDefault);

    std::wstring toString(DWORD dwStrType = CERT_X500_NAME_STR|CERT_NAME_STR_NO_QUOTING_FLAG) const;
    void fromString( 
	const std::wstring& str,
        size_t& pos,
	CACMPT_StringType stringType = stDefault,
        DWORD dwStrType = 0);

    void decode( const CACMPT_BLOB& encoded);
    CACMPT_BLOB encode() const;
private:
    CACMPT_OID type_;
    CACMPT_BLOB value_;
};

typedef std::vector<CACMPT_AttributeTypeAndValue> CACMPT_AttributeTypeAndValueSet;

class CACMPT_RelativeDistinguishedName: public CACMPT_AttributeTypeAndValueSet
{
public:
    CACMPT_RelativeDistinguishedName();
    CACMPT_RelativeDistinguishedName( const std::wstring& str, DWORD dwStrType = 0);
    CACMPT_RelativeDistinguishedName( const std::wstring& str, DWORD dwStrType, 
        size_t& pos);

    std::wstring toString(DWORD dwStrType = CERT_X500_NAME_STR|CERT_NAME_STR_NO_QUOTING_FLAG) const;
    void fromString( const std::wstring& str, DWORD dwStrType = 0);
    void fromString( const std::wstring& str, DWORD dwStrType, size_t& pos);

    void decode( const CACMPT_BLOB& encoded);
    CACMPT_BLOB encode() const;
};

typedef std::list<CACMPT_RelativeDistinguishedName> CACMPT_RDNSequence;

class CACMPT_Name: public CACMPT_RDNSequence
{
public:
    CACMPT_Name();
    CACMPT_Name( const std::wstring& str, DWORD dwStrType = 0, size_t *errorPos = 0 );

    std::wstring toString(DWORD dwStrType = CERT_X500_NAME_STR|CERT_NAME_STR_NO_QUOTING_FLAG) const;
    void fromString( const std::wstring& str, DWORD dwStrType, size_t *errorPos = 0 );

    void decode( const CACMPT_BLOB& encoded);
    CACMPT_BLOB encode() const;
};

bool operator==( const CACMPT_Name& lhs, const CACMPT_Name& rhs);

#endif // _ASN1TYPES_H
