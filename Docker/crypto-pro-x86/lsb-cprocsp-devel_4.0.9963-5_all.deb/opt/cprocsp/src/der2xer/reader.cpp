// This test driver program reads an encoded record from a file         
// and decodes it and displays the results..                            

#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <memory>
#ifdef HAVE_CONFIG_H
#include "myconfig.h"
#endif
#include <iostream>
#ifdef WIN32
    #include <io.h>
    #include <fcntl.h>
#endif //WIN32

#include "ASN1Blob.h"
#include "PKIXCMP.h"
#include "PKIXTSP.h"
#include "PKIXOCSP.h"
#include "PKIXDVCS.h"
using namespace asn1data;
const int MAXMSGLEN=65536;
static ASN1OCTET msgbuf[MAXMSGLEN];
#if 0
static ASN1OCTET msgbuf1[MAXMSGLEN];
#endif // 0

#if !defined UNUSED
#   define UNUSED(x) ((void)(x))
#endif // !UNUSED

static ASN1CType *
CreateType (ASN1MessageBuffer& msgBuf, const char * type_name, void ** asn1T)
{
    if (!strcmp (type_name, "CertificationRequest")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_CertificationRequest);
	return new ASN1C_CertificationRequest (msgBuf, *(ASN1T_CertificationRequest*)*asn1T);
    }
    if (!strcmp (type_name, "Certificate")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_Certificate);
	return new ASN1C_Certificate (msgBuf, *(ASN1T_Certificate*)*asn1T);
    }
    if (!strcmp (type_name, "CertificateList")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_CertificateList);
	return new ASN1C_CertificateList (msgBuf, *(ASN1T_CertificateList*)*asn1T);
    }
    if (!strcmp (type_name, "PKIMessage")) {
	if (!*asn1T)
//	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_PKIMessage);
	    *asn1T = malloc (sizeof(ASN1T_PKIMessage));
	return new ASN1C_PKIMessage(msgBuf, *(ASN1T_PKIMessage*)*asn1T);
    }
    if (!strcmp (type_name, "ContentInfo")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_ContentInfo);
	return new ASN1C_ContentInfo(msgBuf, *(ASN1T_ContentInfo*)*asn1T);
    }
    if (!strcmp (type_name, "EnvelopedData")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_EnvelopedData);
	return new ASN1C_EnvelopedData(msgBuf, *(ASN1T_EnvelopedData*)*asn1T);
    }
    if (!strcmp (type_name, "EncryptedData")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_EncryptedData);
	return new ASN1C_EncryptedData(msgBuf, *(ASN1T_EncryptedData*)*asn1T);
    }
    if (!strcmp (type_name, "CertificateList")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_CertificateList);
	return new ASN1C_CertificateList(msgBuf, *(ASN1T_CertificateList*)*asn1T);
    }
    if (!strcmp (type_name, "TimeStampReq")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_TimeStampReq);
	return new ASN1C_TimeStampReq(msgBuf, *(ASN1T_TimeStampReq*)*asn1T);
    }
    if (!strcmp (type_name, "TimeStampToken")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_TimeStampToken);
	return new ASN1C_TimeStampToken(msgBuf, *(ASN1T_TimeStampToken*)*asn1T);
    }
    if (!strcmp (type_name, "TimeStampResp")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_TimeStampResp);
	return new ASN1C_TimeStampResp(msgBuf, *(ASN1T_TimeStampResp*)*asn1T);
    }
    if (!strcmp (type_name, "TSTInfo")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_TSTInfo);
	return new ASN1C_TSTInfo(msgBuf, *(ASN1T_TSTInfo*)*asn1T);
    }
    if (!strcmp (type_name, "OCSPRequest")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_OCSPRequest);
	return new ASN1C_OCSPRequest(msgBuf, *(ASN1T_OCSPRequest*)*asn1T);
    }
    if (!strcmp (type_name, "OCSPResponse")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_OCSPResponse);
	return new ASN1C_OCSPResponse(msgBuf, *(ASN1T_OCSPResponse*)*asn1T);
    }
    if (!strcmp (type_name, "BasicOCSPResponse")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_BasicOCSPResponse);
	return new ASN1C_BasicOCSPResponse(msgBuf, *(ASN1T_BasicOCSPResponse*)*asn1T);
    }
    if (!strcmp (type_name, "BasicOCSPResponse")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_BasicOCSPResponse);
	return new ASN1C_BasicOCSPResponse(msgBuf, *(ASN1T_BasicOCSPResponse*)*asn1T);
    }
    if (!strcmp (type_name, "DVCSRequest")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_DVCSRequest);
	return new ASN1C_DVCSRequest(msgBuf, *(ASN1T_DVCSRequest*)*asn1T);
    }
    if (!strcmp (type_name, "DVCSResponse")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_DVCSResponse);
	return new ASN1C_DVCSResponse(msgBuf, *(ASN1T_DVCSResponse*)*asn1T);
    }
    if (!strcmp (type_name, "TimeStampAuthenticodeRequest")) {
	if (!*asn1T)
	    *asn1T = ALLOC_ASN1ELEM (msgBuf.getCtxtPtr (), ASN1T_TimeStampAuthenticodeRequest);
	return new ASN1C_TimeStampAuthenticodeRequest(msgBuf, *(ASN1T_TimeStampAuthenticodeRequest*)*asn1T);
    }
    return NULL;
}

static ASN1TDynOctStr*
GetContent (void * asn1T, const char * type_name, const char * type_name1)
{
   if (!strcmp (type_name, "TSTInfo") && !strcmp (type_name1, "TimeStampResp"))
       return &((ASN1T_SignedData*)((ASN1T_TimeStampResp*)asn1T)->timeStampToken.content.decoded)->encapContentInfo.eContent;
   if (!strcmp (type_name, "DVCSRequest") && !strcmp (type_name1, "ContentInfo"))
       return &((ASN1T_SignedData*)((ASN1T_ContentInfo*)asn1T)->content.decoded)->encapContentInfo.eContent;
   if (!strcmp (type_name, "DVCSResponse") && !strcmp (type_name1, "ContentInfo"))
       return &((ASN1T_SignedData*)((ASN1T_ContentInfo*)asn1T)->content.decoded)->encapContentInfo.eContent;
   if (!strcmp (type_name, "BasicOCSPResponse") && !strcmp (type_name1, "OCSPResponse"))
       return &((ASN1T_OCSPResponse*)asn1T)->responseBytes.response;
   return NULL;
}

class XerDerConverter
{
public:
    virtual ~XerDerConverter() {}

    virtual std::string toXer( const CACMPT_BLOB& der, bool includeEncoded) const=0;
    virtual CACMPT_BLOB toDer( const std::string& xer) const=0;
};

class XerDerConverterSimple: public XerDerConverter
{
public:
    XerDerConverterSimple( const std::string& asn1TypeName)
	: asn1TypeName_(asn1TypeName) {}
    ~XerDerConverterSimple() {}

    std::string toXer( const CACMPT_BLOB& der, bool includeEncoded) const;
    CACMPT_BLOB toDer( const std::string& xer) const;
private:
    std::string asn1TypeName_;
};

//virtual 
std::string XerDerConverterSimple::toXer( const CACMPT_BLOB& der, bool includeEncoded) const
{
    ASN1BERDecodeBuffer berDecodeBuffer(der.pbData, der.cbData);
    ASN1XEREncodeBuffer xerEncodeBuffer(FALSE);

    void * asn1T = NULL;
    ASN1CType * asn1CD = CreateType (berDecodeBuffer, asn1TypeName_.c_str(), &asn1T);
    ASN1CType * asn1CE = CreateType (xerEncodeBuffer, asn1TypeName_.c_str(), &asn1T);
    if (!asn1CD || !asn1CE)
	throw CA_EXCEPTION(CAException,"Invalid type");

    int stat = asn1CD->Decode ();
    if (stat != ASN_OK)
	throw CA_ASN1_EXCEPTION(berDecodeBuffer.getCtxtPtr());

    stat = asn1CE->Encode();
    if(stat < 0)
	throw CA_ASN1_EXCEPTION(xerEncodeBuffer.getCtxtPtr());

    std::string xerString(
	reinterpret_cast<const char*>(xerEncodeBuffer.getMsgPtr()),
	xerEncodeBuffer.getMsgLen());

    if( includeEncoded )
    {
	ASN1XEREncodeBuffer xerOctStrEncode(TRUE);
	if( ASN_OK != ::xerEncOctStr(
	    xerOctStrEncode.getCtxtPtr(), der.cbData, der.pbData, "") )
	    throw CA_ASN1_EXCEPTION(xerOctStrEncode.getCtxtPtr());

	std::string hexDer(
	    reinterpret_cast<const char*>(xerOctStrEncode.getMsgPtr()),
	    xerOctStrEncode.getMsgLen());

	std::string::size_type pos = xerString.find_first_of('>',0);
	pos = xerString.find_first_of('>',pos+1);
	xerString.insert(pos+1,hexDer);
    }
    return xerString;
}

//virtual 
CACMPT_BLOB XerDerConverterSimple::toDer( const std::string& xer) const
{
    ASN1XERDecodeBuffer xerDecodeBuffer(
	reinterpret_cast<const ASN1OCTET*>(xer.c_str()), xer.length());
    ASN1BEREncodeBuffer berEncodeBuffer;

    void * asn1T = NULL;
    ASN1CType * asn1CD = CreateType (xerDecodeBuffer, asn1TypeName_.c_str(), &asn1T);
    ASN1CType * asn1CE = CreateType (berEncodeBuffer, asn1TypeName_.c_str(), &asn1T);
    if (!asn1CD || !asn1CE)
	throw CA_EXCEPTION(CAException,"Invalid type");

    int stat = asn1CD->Decode ();
    if (stat != ASN_OK)
	throw CA_ASN1_EXCEPTION(xerDecodeBuffer.getCtxtPtr());

    stat = asn1CE->Encode();
    if(stat < 0)
	throw CA_ASN1_EXCEPTION(berEncodeBuffer.getCtxtPtr());

    return CACMPT_BLOB(berEncodeBuffer.getMsgPtr(),stat);
}

class XerDerConverterTimeStampResponse: public XerDerConverter
{
public:
    XerDerConverterTimeStampResponse() {}
    ~XerDerConverterTimeStampResponse() {}

    std::string toXer( const CACMPT_BLOB& der, bool includeEncoded) const;
    CACMPT_BLOB toDer( const std::string& xer) const;
};

//virtual 
std::string XerDerConverterTimeStampResponse::toXer( const CACMPT_BLOB& der, bool includeEncoded) const
{
    UNUSED(includeEncoded);
    ASN1BERDecodeBuffer berDecodeBuffer(der.pbData, der.cbData);
    ASN1XEREncodeBuffer xerEncodeBuffer(FALSE);

    ASN1T_TimeStampResp t;
    ASN1C_TimeStampResp cD(berDecodeBuffer,t);
    ASN1C_TimeStampResp cE(xerEncodeBuffer,t);

    int stat = cD.Decode ();
    if (stat != ASN_OK)
	throw CA_ASN1_EXCEPTION(berDecodeBuffer.getCtxtPtr());

    stat = cE.Encode();
    if(stat < 0)
	throw CA_ASN1_EXCEPTION(xerEncodeBuffer.getCtxtPtr());

    std::string xer(
	reinterpret_cast<const char*>(xerEncodeBuffer.getMsgPtr()),
	xerEncodeBuffer.getMsgLen());

    ASN1TDynOctStr* octstr = &((ASN1T_SignedData*)((ASN1T_TimeStampResp*)&t)->timeStampToken.content.decoded)->encapContentInfo.eContent;
    ASN1BERDecodeBuffer berDecodeBuffer2(octstr->data, octstr->numocts);
    ASN1XEREncodeBuffer xerEncodeBuffer2(FALSE);
    ASN1T_TSTInfo tInfo;
    ASN1C_TSTInfo cInfoD(berDecodeBuffer2,tInfo);
    ASN1C_TSTInfo cInfoE(xerEncodeBuffer2,tInfo);
    
    stat = cInfoD.Decode ();
    if (stat != ASN_OK)
	throw CA_ASN1_EXCEPTION(berDecodeBuffer.getCtxtPtr());

    stat = cInfoE.Encode();
    if(stat < 0)
	throw CA_ASN1_EXCEPTION(xerEncodeBuffer.getCtxtPtr());

    std::string xerInfo(
	reinterpret_cast<const char*>(xerEncodeBuffer2.getMsgPtr()),
	xerEncodeBuffer2.getMsgLen());

    std::string substr = 
	"<encapContentInfo><eContentType>1.2.840.113549.1.9.16.1.4</eContentType><eContent>";
    size_t pos1 = xer.find(substr,0);
    if( std::string::npos == pos1 )
	throw CA_EXCEPTION(CAException,"Wrong xer");
    pos1 += substr.length();
    substr = "</eContent></encapContentInfo>";
    size_t pos2 = xer.find(substr,pos1);
    if( std::string::npos == pos2 )
	throw CA_EXCEPTION(CAException,"Wrong xer");

    xer.erase( pos1, pos2-pos1);
    xer.insert( pos1, xerInfo);

    return xer;   
}

//virtual 
CACMPT_BLOB XerDerConverterTimeStampResponse::toDer( const std::string& xer) const
{
    UNUSED(xer);
    return CACMPT_BLOB();
}

static std::auto_ptr<XerDerConverter> CreateConverter(
    const std::string& asn1TypeName)
{
    return std::auto_ptr<XerDerConverter>(
	new XerDerConverterSimple(asn1TypeName) );
}

static void usage (bool fxer2der)
{
#if defined _COMPACT
    printf ("usage: %s [-notrace] [-[i|t] <arg>] \n",fxer2der?("xer2der"):("der2xer"));
#else
    printf ("usage: %s [-v|-notrace] [-[i|t] <arg>] \n",fxer2der?("xer2der"):("der2xer"));
    printf ("   -v  verbose mode: print trace info\n");
#endif	// _COMPACT
    printf ("   -i <filename>  read encoded msg from <filename>\n");
    printf ("   -t <type_name>  treat encoded msg as <type_name>\n");
    printf ("      (CertificationRequest, Certificate)\n");
    printf ("   -t1 <type_name> get encoded msg from contents\n");
    printf ("      of other encoded msg (TimeStampResp)\n");
    printf ("   -o <filename>  write DER-encoded inner msg to <filename>\n");
    printf ("      (used with -t1)\n");
    printf ("   -notrace  do not display trace info\n");
    if(!fxer2der)
	printf ("   -includeEncoded  include hex-printed encoded value of der into xer\n");
    printf ("   Supported types:\n");
    printf ("\tCertificationRequest\n");
    printf ("\tCertificate\n");
    printf ("\tCertificateList\n");
    printf ("\tPKIMessage\n");
    printf ("\tContentInfo\n");
    printf ("\tEnvelopedData\n");
    printf ("\tEncryptedData\n");
    printf ("\tCertificateList\n");
    printf ("\tTimeStampReq\n");
    printf ("\tTimeStampToken\n");
    printf ("\tTimeStampResp\n");
    printf ("\tTimeStampAuthenticodeRequest\n");
    printf ("\tTSTInfo\n");
    printf ("\tOCSPRequest\n");
    printf ("\tOCSPResponse\n");
    printf ("\tBasicOCSPResponse\n");
    printf ("\tDVCSRequest\n");
    printf ("\tDVCSResponse\n");
}

int main (int argc, char** argv)
{
    int		i, len, stat;
    FILE*        fp;
    const char*  filename = "message.dat";
    const char*  filename1 = NULL;
    const char*  type_name = "CertificationRequest";
    const char*  type_name1 = "";
    //    ASN1BOOL     trace = TRUE;
    bool		fxer2der = false;
    bool includeEncoded = false;

    std::string argv0(argv[0]);
    std::string slashes("\\/");
    size_t pos = argv0.find_last_of(slashes);
    if( pos == std::string::npos )
	pos = 0;
    if( argv0.find("xer2der",pos) != std::string::npos )
	fxer2der = true;

    // Process command line arguments 

    if (argc > 1) {
	for (i = 1; i < argc; i++) {
#if !defined _COMPACT
	    if (!strcmp (argv[i], "-v")) rtSetDiag (1);
	    else
#endif	// !_COMPACT
		 if (!strcmp (argv[i], "-i")) filename = argv[++i];
	    else if (!strcmp (argv[i], "-o")) filename1 = argv[++i];
	    else if (!strcmp (argv[i], "-t")) type_name = argv[++i];
	    else if (!strcmp (argv[i], "-t1")) type_name1 = argv[++i];
	    else if (!strcmp (argv[i], "-notrace")) ; //trace = FALSE;
	    else if (!strcmp (argv[i], "-includeEncoded")) includeEncoded = true;
	    else {
		usage (fxer2der);
		return 0;
	    }
	}
    } else {
	usage (fxer2der);
	return 0;
    }

    if( fxer2der && includeEncoded )
    {
	printf("Option -includeEncoded can be used in der2xer only.\n");
	return 0;
    }

    // Read input file into a memory buffer 

    if ((fp = fopen (filename, "rb"))) {
	len = fread (msgbuf, 1, sizeof(msgbuf), fp);
	fclose (fp);
    }
    else {
	printf ("Error opening %s for read access\n", filename);
	return -1;
    }

    // Decode 

    if (*type_name1)
    {
	ASN1BERDecodeBuffer decodeBuffer (msgbuf, len);
	void * asn1T = NULL;
	ASN1CType * asn1CD = CreateType (decodeBuffer, type_name1, &asn1T);

	stat = asn1CD->Decode ();
	if (stat != ASN_OK)
	{
	    printf ("decode of %s failed\n", type_name1);
	    decodeBuffer.PrintErrorInfo ();
	    exit (-1);
	}
	ASN1TDynOctStr* octets = GetContent (asn1T, type_name, type_name1);
	if (!octets)
	{ 
	    printf ("Invalid type combination\n");
	    exit (-1);
	}
	len = octets->numocts;
	memcpy (msgbuf, octets->data, octets->numocts);
	if (filename1)
	{
	    if ((fp = fopen (filename1, "wb"))) {
		fwrite (msgbuf, 1, len, fp);
		fclose (fp);
	    }
	    else {
		printf ("Error opening %s for write access\n", filename1);
	    }
	}
    }

    std::auto_ptr<XerDerConverter> xdConv = ::CreateConverter(type_name);
    if(!xdConv.get())
    {
	printf("Wrong type\n");
	return -1;
    }

    if(fxer2der)
    {
	CACMPT_BLOB der = xdConv->toDer( 
	    std::string(reinterpret_cast<const char*>(msgbuf),len) );
#ifdef WIN32
	int prevmode = ::_setmode(1,_O_BINARY);
	::_write(1,der.pbData,der.cbData);
	::_setmode(1,prevmode);
#else // WIN32
        std::cout.write(reinterpret_cast<char*>(der.pbData),der.cbData);
#endif // WIN32
    }
    else
    {
	try {
	    std::string xer = xdConv->toXer( CACMPT_BLOB(msgbuf,len), includeEncoded );
	    std::cout << xer;
	}
	catch( CAException ex )
	{
	    std::cerr << "Error:" << ex.what() << std::endl;
	}
	catch( std::exception &ex )
	{
	    std::cerr << "Exception:" << ex.what() << std::endl;
	}
	catch( ... )
	{
    	    std::cerr << "Unknown exception." << std::endl;
	}
    }

#if 0
    ASN1BERDecodeBuffer berDecodeBuffer (msgbuf, len);
    ASN1XEREncodeBuffer xerEncodeBuffer (msgbuf1, sizeof(msgbuf1), FALSE);
    ASN1XERDecodeBuffer xerDecodeBuffer (msgbuf, len);
    ASN1BEREncodeBuffer berEncodeBuffer (msgbuf1, sizeof(msgbuf1));

    ASN1MessageBuffer& decodeBuffer = fxer2der?dynamic_cast<ASN1MessageBuffer&>(xerDecodeBuffer):
    dynamic_cast<ASN1MessageBuffer&>(berDecodeBuffer);
    ASN1MessageBuffer& encodeBuffer = fxer2der?dynamic_cast<ASN1MessageBuffer&>(berEncodeBuffer):
    dynamic_cast<ASN1MessageBuffer&>(xerEncodeBuffer);

    void * asn1T = NULL;
    ASN1CType * asn1CD = CreateType (decodeBuffer, type_name, &asn1T);
    ASN1CType * asn1CE = CreateType (encodeBuffer, type_name, &asn1T);
    if (!asn1CD || !asn1CE) {
	printf ("Invalid type\n");
	exit (-1);
    }

    stat = asn1CD->Decode ();

    if (stat == ASN_OK)
    {
	if (trace)
	{   
	    stat = asn1CE->Encode();
	    if(stat >= 0)
	    {
		if (trace) 
		{
		    fwrite (
			fxer2der?(berEncodeBuffer.getMsgPtr()):(xerEncodeBuffer.getMsgPtr()),
			fxer2der?(stat):(xerEncodeBuffer.getMsgLen()), 1, stdout);
		}
	    }
	    else
	    {
		printf ("Encoding failed\n");
		encodeBuffer.printErrorInfo ();
		exit (-1);
	    }
	}
    }
    else
    {
	printf ("decode of %s failed\n", type_name);
	decodeBuffer.PrintErrorInfo ();
	exit (-1);
    }
#endif

    return 0;
}
