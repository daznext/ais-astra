#include "reader.kit/gen_prj.h"
#include "reader/tchar.h"

#include "reader/rdr.h"
#include "reader/rdr_fkc.h"
#ifndef UNIX
#include "reader/rdr_wnd.h"
#endif /* UNIX */
#include "reader/support.h"

#define RDR_ITEMR2(name,arg_list,call_list,type,conv,err) \
    SUPDLL_ITEMT(rdr,name,arg_list,type,conv)
#define RDR_ITEM(name,arg_list,call_list) \
    SUPDLL_ITEMT(rdr,name,arg_list,TSupErr,SUPDLL_NULL)
#include "rdr_def.h"
#undef RDR_ITEMR2
#undef RDR_ITEM

SUPDLL_ITEMI_B_INSIDE(rdr)
#define RDR_ITEMR2(name,arg_list,call_list,type,conv,err) \
    SUPDLL_ITEMI(rdr,name)
#define RDR_ITEM(name,arg_list,call_list) \
    SUPDLL_ITEMI(rdr,name)
#include "rdr_def.h"
#undef RDR_ITEMR2
#undef RDR_ITEM
SUPDLL_ITEMI_E(rdr)

static const TCHAR RDR_DEFAULT_NAME[] = 
#ifdef UNIX
_TEXT( "librdrrdr.so" );
#else /* UNIX */
_TEXT( "cprdr.dll" );
#endif /* UNIX */
#define rdr_module_init()
#define rdr_module_done()
SUPDLL_LOAD(rdr,RDR_DEFAULT_NAME)
SUPDLL_UNLOAD(rdr)

#define RDR_ITEMR2(name,arg_list,call_list,type,conv,err) \
    SUPDLL_ITEMR2(rdr,name,arg_list,call_list,type,conv,err)
#define RDR_ITEM(name,arg_list,call_list) \
    SUPDLL_ITEMR2(rdr,name,arg_list,call_list,TSupErr,SUPDLL_NULL,SUP_ERR_UNSUPPORTED)
#include "rdr_def.h"
