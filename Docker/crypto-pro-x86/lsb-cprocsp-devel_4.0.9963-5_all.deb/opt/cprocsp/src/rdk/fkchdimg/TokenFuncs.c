#include "fkchdimgprj.h"

DWORD
SetPublicKeyBlob(TOKEN_CONTAINER* pTKN)
{
    DWORD err;
    BYTE* pBuff =NULL;
    DWORD dwBlobLen;
    
    err = CreatePublicKeyBlob(pTKN->hKeyPair, &dwBlobLen, &pBuff);
    if(err) {
	if (pBuff)
	    free (pBuff);
	goto done;
    }
        
    if (pTKN->pbPublicKeyBlob)
	free (pTKN->pbPublicKeyBlob);
    
    pTKN->pbPublicKeyBlob = pBuff;
    pTKN->dwPubBlobLen = dwBlobLen;

done:
    return err;
}

DWORD
FKCAddPubKey(HCRYPTPROV hProv, LPBYTE pbPubKeyBlobA, LPBYTE pbPubKeyBlobB, 
	     DWORD* pdwBlobLen, DWORD dwECCSign, LPBYTE* ppbPubKeyBlobRes, DWORD * err_in_add)
{
    HCRYPTKEY hPubKeyA=0;
    DWORD err =0, dwBlobLen=*pdwBlobLen;
    CRYPT_DATA_BLOB dB;

    dB.cbData = dwBlobLen;
    dB.pbData = pbPubKeyBlobB;
  /* Public key A */
    if(!CryptImportKey(hProv, pbPubKeyBlobA, dwBlobLen, 0, 0, &hPubKeyA))
	err = GetLastError();
    if(err) goto done;
  /* pbPubKeyBlobA +- pbPubKeyBlobB */
    if(!dwECCSign) {
	if(!CryptSetKeyParam(hPubKeyA, KP_ECADD, (BYTE *)&dB,0))
	    err = GetLastError();
    } else {
	if(!CryptSetKeyParam(hPubKeyA, KP_ECSUB, (BYTE *)&dB,0))
	    err = GetLastError();
    }
    if(err) {
	*err_in_add = err;
	err = 0;
	goto done;
    }
  /* Public key Blob*/
    dwBlobLen = 0;
    if(!CryptExportKey(hPubKeyA, 0, PUBLICKEYBLOB, 0, NULL, &dwBlobLen))
	err = GetLastError();
    if(err) goto done;

    if(!*ppbPubKeyBlobRes)
	*ppbPubKeyBlobRes = malloc(dwBlobLen);	
    if(!*ppbPubKeyBlobRes) {
	err = (DWORD)NTE_NO_MEMORY;
	goto done;
    }

    if(!CryptExportKey(hPubKeyA, 0, PUBLICKEYBLOB, 0, *ppbPubKeyBlobRes, &dwBlobLen))
	err = GetLastError();
    if(err) goto done;
    *pdwBlobLen = dwBlobLen;

    CryptDestroyKey(hPubKeyA);
    return 0;

 done:
    if(hPubKeyA) CryptDestroyKey(hPubKeyA);
    return err;
}

DWORD
FKCSetDelta_e(LPTOKEN_CONTAINER pFKC, LPBYTE pbData)
{
    CRYPT_DATA_BLOB dB;
    DWORD err=0;
    dB.pbData = pbData;
    dB.cbData = SECRET_KEY_LEN;
    if(!CryptSetKeyParam(pFKC->hKeyPair,KP_ADDX,(LPBYTE)&dB,0))
    {
	err = GetLastError();
    }
    return err;
}
