#ifndef _FKCHDIMGEKE_H_
#define _FKCHDIMGEKE_H_

typedef struct _EKE_CONTAINER {
    HCRYPTKEY			hEKEAgree_A_B;
    DWORD			Verify_A;
    DWORD			Verify_B;
    LPBYTE			pbEKE_MA_Verify;
    LPBYTE			pbEKE_MB_Verify;
    TRdrFkcEKEChallenge_id	curChalID;
    TRdrFkcEKEChallenge_class	curChalClass;
} EKE_CONTAINER, *LPEKE_CONTAINER;

BOOL eke_cont_init (LPEKE_CONTAINER * new_cont);
void eke_cont_release (LPEKE_CONTAINER cont);
DWORD FKCVerifyEKE(LPEKE_CONTAINER pEKE, DWORD pEKEData);
DWORD FKCEKEEncrypt(LPEKE_CONTAINER pEKE, DWORD CryptMode, BOOL bEncrypt, LPBYTE pbData, DWORD cbData);

#endif /*_FKCHDIMGEKE_H_*/
