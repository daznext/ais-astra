#include "tst12prj.h" /*+ Project (READER/FAT12/TEST) include.
    ������ include ���� ��� ������� (READER/FAT12/TEST). +*/
#include <stdio.h>

DWORD
SetTokenData(DWORD dwControl,LPBYTE pbData,DWORD cbData,PTOKEN_DATA pData)
{
    free(pData->pbData);
    pData->pbData = malloc(cbData);
    if(!pData->pbData)
	return (DWORD)NTE_NO_MEMORY;
    pData->cbData = cbData;
    pData->tControl = dwControl;
    pData->tVerify = 0;
    if(pbData)
	CopyMemory(pData->pbData,pbData,cbData);
    return 0;
}

void
FreeTokenData(PTOKEN_DATA pData)
{
    if(!pData)
	return;
    if(pData->pbData) {
	ZeroMemory(pData->pbData,pData->cbData);
	free(pData->pbData);
	pData->pbData = NULL;
    }
    pData->cbData = 0;
    pData->tVerify = 0;
}

DWORD SetPublicTokenContainer(PTOKEN_DATA pData,LPTOKEN_CONTAINER pCont)
{
    LPBYTE pbPublic = NULL;
    switch(pData->tControl) {
	case id_Q_PW:
	case id_Q_PW_0:
	case id_Q_FKC:
	case id_Q_S:
	case id_Q_USER:
	    break;
    default:
	return (DWORD) NTE_INVALID_PARAMETER;
    }

    switch(pData->tControl) {
	case id_Q_PW:
	case id_Q_PW_0:
	    pbPublic = pCont->pbPWPublicKeyBlob;
	    break;
	case id_Q_FKC:
	    pbPublic = pCont->pbFKCPublicKeyBlob;
	    break;
	case id_Q_S:
	    pbPublic = pCont->pbSaltPublicBlob;
	    break;
	case id_Q_USER:
	    pbPublic = pCont->pbUserPublicKeyBlob;
	    break;
    }
    if(!pbPublic) {
	pbPublic = malloc(pData->cbData);
	if(!pbPublic)
	    return (DWORD)NTE_NO_MEMORY;
	switch(pData->tControl) {
	    case id_Q_PW:
	    case id_Q_PW_0:
		pCont->pbPWPublicKeyBlob = pbPublic;
		break;
	    case id_Q_FKC:
		pCont->pbFKCPublicKeyBlob = pbPublic;
		break;
	    case id_Q_S:
		pCont->pbSaltPublicBlob = pbPublic;
		break;
	    case id_Q_USER:
		pCont->pbUserPublicKeyBlob = pbPublic;
		break;
	}
    }
    CopyMemory(pbPublic, pData->pbData, pData->cbData);
    return 0;
}

DWORD SetDataPublicTokenContainer(DWORD tControl,BYTE* pbData, DWORD cbData,LPTOKEN_CONTAINER pCont)
{
    LPBYTE pbPublic = NULL;
    switch(tControl) {
	case id_Q_PW:
	case id_Q_PW_0:
	case id_Q_FKC:
	case id_Q_S:
	case id_Q_USER:
	case id_PublicKeyBlob:
	    break;
    default:
	return (DWORD) NTE_INVALID_PARAMETER;
    }

    switch(tControl) {
	case id_Q_PW:
	case id_Q_PW_0:
	    pbPublic = pCont->pbPWPublicKeyBlob;
	    break;
	case id_Q_FKC:
	    pbPublic = pCont->pbFKCPublicKeyBlob;
	    break;
	case id_Q_S:
	    pbPublic = pCont->pbSaltPublicBlob;
	    break;
	case id_Q_USER:
	    pbPublic = pCont->pbUserPublicKeyBlob;
	    break;
	case id_PublicKeyBlob:
	    pbPublic = pCont->pbPublicKeyBlob;
	    break;
    }
    if(!pbPublic) {
	pbPublic = malloc(cbData);
	if(!pbPublic)
	    return (DWORD)NTE_NO_MEMORY;
	switch(tControl) {
	    case id_Q_PW:
	    case id_Q_PW_0:
		pCont->pbPWPublicKeyBlob = pbPublic;
		break;
	    case id_Q_FKC:
		pCont->pbFKCPublicKeyBlob = pbPublic;
		break;
	    case id_Q_S:
		pCont->pbSaltPublicBlob = pbPublic;
		break;
	    case id_Q_USER:
		pCont->pbUserPublicKeyBlob = pbPublic;
		break;
	    case id_PublicKeyBlob:
		pCont->pbPublicKeyBlob = pbPublic;
		break;
	}
    }
    CopyMemory(pbPublic,pbData,cbData);
    return 0;
}

DWORD
SetPublicKeyBlob_test(TOKEN_CONTAINER* pTKN)
{
    DWORD err =0;
    BYTE* pBuff =NULL;
    DWORD dwBlobLen;
    
    err = CreatePublicKeyBlob_test(pTKN->hKeyPair, &dwBlobLen, &pBuff);
    if(err) goto done;

    err = SetDataPublicTokenContainer(id_PublicKeyBlob,pBuff,dwBlobLen,pTKN);
    if(err) goto done;

    if(pTKN->hPublicKey)
	CryptDestroyKey(pTKN->hPublicKey);
    pTKN->hPublicKey = 0;
    if(!CryptImportKey(pTKN->hContainer, pTKN->pbPublicKeyBlob, dwBlobLen, 0, 0, &(pTKN->hPublicKey)))
	err = GetLastError();

done:
    free(pBuff);
    return err;
}

DWORD
FKCAddPubKey_t(HCRYPTPROV hProv, LPBYTE pbPubKeyBlobA, LPBYTE pbPubKeyBlobB, 
	     DWORD* pdwBlobLen, DWORD dwECCSign, LPBYTE* ppbPubKeyBlobRes)
{
    HCRYPTKEY hPubKeyA=0;
    DWORD err =0,dwBlobLen=*pdwBlobLen;
    CRYPT_DATA_BLOB dB;
    dB.cbData = dwBlobLen;
    dB.pbData = pbPubKeyBlobB;

  /* Public key A */
    if(!CryptImportKey(hProv, pbPubKeyBlobA, dwBlobLen, 0, 0, &hPubKeyA)) {
	err = GetLastError();
	goto done;
    }
  /* pbPubKeyBlobA +- pbPubKeyBlobB */
    if(!dwECCSign) {
	if(!CryptSetKeyParam(hPubKeyA, KP_ECADD, (BYTE *)&dB, 0)) {
	    err = GetLastError();
	    goto done;
	}
    } else {
	if(!CryptSetKeyParam(hPubKeyA, KP_ECSUB, (BYTE *)&dB, 0)) {
	    err = GetLastError();
	    goto done;
	}
    }
  /* Public key Blob*/
    dwBlobLen = 0;
    if(!CryptExportKey(hPubKeyA, 0, PUBLICKEYBLOB, 0, NULL, &dwBlobLen)) {
	err = GetLastError();
	goto done;
    }

    *ppbPubKeyBlobRes = malloc(dwBlobLen);	
    if(!*ppbPubKeyBlobRes) {
	err = (DWORD)NTE_NO_MEMORY;
	goto done;
    }

    if(!CryptExportKey(hPubKeyA, 0, PUBLICKEYBLOB, 0, *ppbPubKeyBlobRes, &dwBlobLen)) {
	err = GetLastError();
	goto done;
    }
    *pdwBlobLen = dwBlobLen;

    CryptDestroyKey(hPubKeyA);
    return 0;

 done:
    if(hPubKeyA) CryptDestroyKey(hPubKeyA);
    return err;
}

/*************************************************
	    FKC FUNCS
******************************************************/
DWORD
FKCVerifySign(HCRYPTPROV hProv, LPBYTE pbPubKeyBlob, DWORD dwBlobLen, BYTE *text, DWORD textlen, 
	      BYTE *pbSignature)
{
    HCRYPTHASH hHash;
    HCRYPTKEY hPubKey;
    DWORD err =0, dwHashLen = SECRET_KEY_LEN, dwSigLen = 2*SECRET_KEY_LEN;
    BYTE pbHashVal[SECRET_KEY_LEN];

    if(!CryptCreateHash( hProv, CALG_GR3411, 0, 0, &hHash)) {
	err = GetLastError();
	goto done;
    }

    if(!CryptHashData( hHash, text, textlen, 0)) {
	err = GetLastError();
	goto done;
    }

    if(!CryptGetHashParam( hHash, HP_HASHVAL, (LPBYTE)pbHashVal, &dwHashLen, 0)) {
	err = GetLastError();
	goto done;
    }

    if(!CryptImportKey( hProv, pbPubKeyBlob, dwBlobLen, 0,0, &hPubKey)) {
	err = GetLastError();
	goto done;
    }

    if(!CryptVerifySignature( hHash, pbSignature,dwSigLen, hPubKey, NULL, 0)) {
	err = GetLastError();
	if((HRESULT)err == NTE_BAD_SIGNATURE) {
	    printf("\n Signature faild to validate!\n");
	} else {
	    printf("Error %lx during VerifySignature!\n", (unsigned long)err);
	}
	goto done;
    }
    CryptDestroyKey(hPubKey);
    CryptDestroyHash(hHash);
    return 0;

done:
  return err;
}
