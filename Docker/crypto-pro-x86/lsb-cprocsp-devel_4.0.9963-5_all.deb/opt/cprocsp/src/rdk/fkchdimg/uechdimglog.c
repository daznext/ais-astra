#include "fkchdimgprj.h"

static TSupErr uechdimg_verify_pin( TUECHDImgContext *ctx, char * in_pin, long * ret, BYTE pin_number ) {
    TSupErr code = 0;
    char * saved_pin = NULL;
    size_t saved_pin_len = 0;
    long retries = *ret;
    TCHAR * pin_path = NULL;
    TCHAR * pin_count_path = NULL;
    
    if (pin_number == UEC_PIN2) {
	pin_path = ctx->pin_path;
	pin_count_path = ctx->pin_count_path;
    }
    else if (pin_number == UEC_PUK) {
	pin_path = ctx->puk_path;
	pin_count_path = ctx->puk_count_path;
    }
    else 
	return SUP_ERR_PARAM;

    code = support_registry_get_hex(pin_path, &saved_pin_len, NULL);
    if (code)
	return code;

    saved_pin = malloc (saved_pin_len + 1);
    if (!saved_pin)
	return SUP_ERR_MEMORY;

    code = support_registry_get_hex(pin_path, &saved_pin_len, saved_pin);
    if (code) {
	free (saved_pin);
	return code;
    }
    saved_pin[saved_pin_len] = '\0';

    if (strcmp (saved_pin, in_pin)) {
	if (saved_pin) free (saved_pin);
	code = support_registry_get_long (pin_count_path, &retries);
	if (code) {
	    code = support_registry_put_long(pin_count_path, MAX_PIN_TRIES);
	    if (code)
		return code;
	    code = support_registry_get_long (pin_count_path, &retries);
	    if (code)
		return code;
	}
	if (retries == 0)
	    return RDR_ERR_PASSWD_LOCKED;
	retries--;
	code = support_registry_put_long(pin_count_path, retries);
	if (code)
	    return code;
	*ret = retries;
	return RDR_ERR_INVALID_PASSWD;
    }
    *ret = MAX_PIN_TRIES;
    free (saved_pin);
    return SUP_ERR_NO;
}

TSupErr uechdimg_login( TSupSysContext *context, TSupSysInfo *info )
{
    TReaderInfoLogin *inf = (TReaderInfoLogin*)info;
    TUECHDImgContext *ctx = (TUECHDImgContext*)context;

    TSupErr code;
    TCHAR *passwd;
    char in_pin [10] = {0};
    long retries = 0;

    SUPSYS_PRE_INFO( info, TReaderInfoLogin );

    passwd = inf->passwd.text;
    if( inf->passwd.length > 8 )
	return RDR_ERR_INVALID_PASSWD_FORMAT;
    if( passwd )
	_2asciicpy( in_pin, passwd );

    inf->size_of = sizeof( TReaderInfoLogin );

    code = uechdimg_verify_pin (ctx, in_pin, &retries, UEC_PIN2);
    inf->retries = retries;

    return code;
}

TSupErr uechdimg_puk_enter( TSupSysContext *context, TSupSysInfo *info )
{
    TReaderInfoLogin *inf = (TReaderInfoLogin*)info;
    TUECHDImgContext *ctx = (TUECHDImgContext*)context;

    TSupErr code;
    TCHAR *passwd;
    char in_pin [10] = {0};
    long retries = 0;

    SUPSYS_PRE_INFO( info, TReaderInfoLogin );

    passwd = inf->passwd.text;
    if( inf->passwd.length > 8 )
	return RDR_ERR_INVALID_PASSWD_FORMAT;
    if( passwd )
	_2asciicpy( in_pin, passwd );

    inf->size_of = sizeof( TReaderInfoLogin );

    code = uechdimg_verify_pin (ctx, in_pin, &retries, UEC_PUK);
    inf->retries = retries;

    return code;
}

TSupErr uechdimg_logout( TSupSysContext *context, TSupSysInfo *info )
{
    UNUSED (info);
    UNUSED(context);

    return SUP_ERR_NO;
}

TSupErr uechdimg_change_pin( 
		       TSupSysContext *context, 
		       TSupSysInfo *info )
{
    TReaderInfoPasswdChange *inf = (TReaderInfoPasswdChange*)info;
    TUECHDImgContext *ctx = (TUECHDImgContext*)context;
    char data[9];

    if( inf->new_passwd.length > 8 )
	return RDR_ERR_INVALID_PASSWD_FORMAT;
    
    memset (&data[0], 0, 9);
    _2asciicpy(data, inf->new_passwd.text);

    return support_registry_put_hex(ctx->pin_path, strlen(data), &data[0]);
}

TSupErr uechdimg_clear_tries( 
			TSupSysContext *context, 
			TSupSysInfo *info )
{
    TReaderInfoClearTries *inf = (TReaderInfoClearTries*)info;
    TUECHDImgContext *ctx = (TUECHDImgContext*)context;

    UNUSED (inf);
    SUPSYS_PRE_CONTEXT( context, TUECHDImgContext );
    SUPSYS_PRE_INFO( info, TReaderInfoLogin );

    return support_registry_put_long(ctx->pin_count_path, MAX_PIN_TRIES);
}


