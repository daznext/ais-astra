#include "fkchdimgprj.h"

static DWORD LoadKeyFromRegistry (TUECHDImgContext * ctx, HCRYPTPROV hProv, HCRYPTKEY *hKey_out) 
{    
    DWORD err = 0;
    HCRYPTKEY hKey = 0;
    HCRYPTKEY hKeyEnc = 0;
    HCRYPTHASH hHash = 0;
    BYTE * pass_key = NULL;
    size_t pass_key_length = 0;
    ALG_ID ExportAlgid = CALG_PRO_EXPORT;
    BYTE * pass = (BYTE*) MAGIC_IMPORT_KEY_CONST;
    DWORD pass_len = (DWORD) strlen ((char*)MAGIC_IMPORT_KEY_CONST);
    TSupErr code = SUP_ERR_NO;

    code = support_registry_get_hex(ctx->key_blob_path, &pass_key_length, NULL);
    if (code) {
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "support_registry_get_hex: %x"), code));
	err = (DWORD)NTE_FAIL;
	goto done;
    }
    pass_key = malloc (pass_key_length);
    if (!pass_key) {
	err = (DWORD) NTE_NO_MEMORY;
	goto done;
    }
    err = support_registry_get_hex(ctx->key_blob_path, &pass_key_length, pass_key);
    if (err) {
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "uec_get_pass_key: %x"), err));
	goto done;
    }

    if (!CryptCreateHash(hProv, CALG_GR3411, 0, 0, &hHash )) {
	err = (DWORD)GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptCreateHash: %x"), err));
	goto done;
    }

    if (!CryptHashData(hHash, pass, pass_len, 0)) {
	err = (DWORD)GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptHashData: %x"), err));
	goto done;
    }

    if (!CryptDeriveKey(hProv, CALG_G28147, hHash, 0, &hKeyEnc)) {
	err = (DWORD)GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptDeriveKey: %x"), err));
	goto done;
    }
    if (!CryptSetProvParam(hProv, PP_SIGNATURE_PIN, (BYTE*)MAGIC_PIN, 0)) {
	err = (DWORD)GetLastError();
	//DbTrace(DB_TRACE, (FTEXT(db_ctx, "Error CryptSetProvParam: %x"), err));
	goto done;
    }	
    if (!CryptSetKeyParam(hKeyEnc, KP_ALGID, (BYTE*)&ExportAlgid, 0)){
	err = (DWORD)GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptSetProvParam: %x"), err));
	goto done;
    }

    if (!CryptImportKey(hProv, pass_key, (DWORD)pass_key_length, hKeyEnc, CRYPT_EXPORTABLE, &hKey)) {
	err = (DWORD)GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptImportKey: %x"), err));
	goto done;
    }
    *hKey_out = hKey;

done:
    if (hHash) CryptDestroyHash(hHash);
    if (hKeyEnc) CryptDestroyKey(hKeyEnc);
    if (pass_key) free (pass_key);
    return err;
}

TSupErr uechdimg_sign(TSupSysContext *context, TSupSysInfo *info)
{
    TSupErr code = SUP_ERR_NO; 
    BYTE sign [64];
    DWORD sign_len = 64;
    HCRYPTHASH hHash = 0;
    HCRYPTPROV hProv = 0;
    HCRYPTKEY hKey = 0;
    DWORD err;
    TReaderFkcSignInfo * si = (TReaderFkcSignInfo *)info;
    TUECHDImgContext *ctx = (TUECHDImgContext*)context;

    SUPSYS_PRE_INFO( info, TReaderFkcSignInfo );

    if (!si->UEC.signature) {
	si->UEC.signature_len = 0x40;
	return SUP_ERR_NO;
    }

    if (!CryptAcquireContext (&hProv, NULL, NULL, 75, CRYPT_VERIFYCONTEXT)) {
	//err = GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptImportKey: %x"), err));
	code = SUP_ERR_UNKNOWN;
	goto done;
    }
    err = LoadKeyFromRegistry(ctx, hProv, &hKey);
    if (err) {
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "LoadKeyFromRegistry: %x"), err));
	code = SUP_ERR_UNKNOWN;
	goto done;
    }
    if (!CryptCreateHash(hProv, CALG_GR3411, 0, 0, &hHash)) {
	//err = GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptCreateHash: %x"), err));
	code = SUP_ERR_UNKNOWN;
	goto done;
    }
    if (!CryptSetHashParam(hHash, HP_HASHVAL, si->UEC.hash, 0)) {
	//err = GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptSetHashParam: %x"), err));
	code = SUP_ERR_UNKNOWN;
	goto done;
    }

    if (!CryptSignHash (hHash, AT_KEYEXCHANGE, NULL, 0, sign, &sign_len))
    {
	//err = GetLastError();
	//DbTrace(DB_ERROR, (FTEXT(db_ctx, "CryptSignHash: %x"), err));
	code = SUP_ERR_UNKNOWN;
	goto done;
    }

    memcpy (si->UEC.signature, &sign[0], sign_len);

done:
    if (hKey) {
	CryptDestroyKey(hKey);
	hKey = 0;
    }
    if (hHash) {
	CryptDestroyHash(hHash);
	hHash = 0;
    }
    if (hProv) {
	CryptReleaseContext(hProv, 0);
	hProv = 0;
    }
    return code;
}
