#include "fkchdimgprj.h"

TSupErr uechdimg_folder_open( TSupSysContext *context, TSupSysInfo *info )
{
    TReaderInfoFolderOpen *inf = (TReaderInfoFolderOpen *)info;    
    TUECHDImgContext *ctx = (TUECHDImgContext*)context;

    SUPSYS_PRE_INFO( info, TReaderInfoFolderOpen  );
    SUPSYS_PRE_CONTEXT( context, TUECHDImgContext );

    ctx->folder = 1;
    inf->size_of = sizeof( TReaderInfoFolderOpen );
    return SUP_ERR_NO;
}

TSupErr uechdimg_folder_close( TSupSysContext *context, TSupSysInfo *info )
{
    TReaderInfoFolderClose *inf = (TReaderInfoFolderClose*)info;
    TUECHDImgContext *ctx = (TUECHDImgContext*)context;

    SUPSYS_PRE_INFO( info, TReaderInfoFolderClose  );
    SUPSYS_PRE_CONTEXT( context, TUECHDImgContext );

    ctx->folder = 0;

    inf->size_of = sizeof( TReaderInfoFolderClose );
    return SUP_ERR_NO;
}
