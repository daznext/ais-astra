/*
 * Copyright(C) 2000 ������ ���
 *
 * ���� ���� �������� ����������, ����������
 * �������������� �������� ������ ���.
 *
 * ����� ����� ����� ����� �� ����� ���� �����������,
 * ����������, ���������� �� ������ �����,
 * ������������ ��� �������������� ����� ��������,
 * ���������������, �������� �� ���� � ��� ��
 * ����� ������������ ������� ��� ����������������
 * ���������� ���������� � ��������� ������ ���.
 */

/*!
 * \file $RCSfile$
 * \version $Revision: 126987 $
 * \date $Date:: 2015-09-08 16:51:58 +0300#$
 * \author $Author: pav $
 * \brief ������� ���������� ��������������
 */

#include "fkchdimgprj.h"

/*todo*/
TSupErr fkchdimg_eke_auth_challenge ( 
    TSupSysContext *context, 
    TSupSysInfo *info )
{
    TReaderInfoAuthChallenge * chal = (TReaderInfoAuthChallenge *)info;
    TFKCHDImgContext * ctx = (TFKCHDImgContext*)context;
    TSupErr err = RDR_ERR_BLOCK;

    SUPSYS_PRE_CONTEXT( context, TFKCHDImgContext );
    SUPSYS_PRE_INFO( info, TReaderInfoAuthChallenge );

    SUPSYS_PRE(TRLIT_class(chal->type)==TRLITc_eke);
    SUPSYS_PRE(TRLIT_type(chal->type)==TRLITt_container);

    err = init_read(ctx);
    if (err) goto done;

    if(isCNULL(ctx)
	||(chal->id == TRECi_syncroBIS)
	||(chal->id == TRECi_deltaBIS)
	||(chal->id == TRECi_Qpw)) 
    {
	err= SUP_ERR_CANCEL;
	goto done;
    }

    if (!ctx->cont.C.c_eke) {
	err = RDR_ERR_FKC_OPLIMIT_REACHED;
	goto doneErr;
    }

    switch(chal->Class)
    {
#if _DEBUG
    case TRECc_first_dbg:
	{
	    BYTE u1point [PUBLICBLOBLEN];
	    BYTE u2point [PUBLICBLOBLEN];
	    BYTE secretB [SECRET_KEY_LEN];
	    const TRdrFkcEKEChallengeFirst2fkc_debug * _2fkc;
	    TRdrFkcEKEChallengeFirst2csp * _2csp;
	    
	    _2fkc = CONSTP2CH(TRdrFkcEKEChallengeFirst2fkc_debug, chal->toFolder);
	    _2csp = P2CH(TRdrFkcEKEChallengeFirst2csp, chal->fromFolder);

	    if (_2fkc->IsNewTr == FKC_TRANSACTION_IS_NEW) {
		ctx->cont.curmask = FKC_TRANS_SET_ZERO;
		ctx->cont.curtrid = _2fkc->TrId;
	    } else {
		if (ctx->cont.curtrid) {
		    if (ctx->cont.curtrid != _2fkc->TrId) {
			err = RDR_ERR_FKC_TRANSACTION;
			goto done;
		    }
		}
	    }

	    if (ctx->cont.lpEKEop) eke_cont_release (ctx->cont.lpEKEop);
	    eke_cont_init(&(ctx->cont.lpEKEop));

	    ctx->cont.lpEKEop->curChalClass = TRECc_first;
	    ctx->cont.lpEKEop->curChalID = chal->id;

	    makePublicBlob(&ctx->cont,u1point,(LPBYTE)_2fkc->u1.x, (LPBYTE)_2fkc->u1.y);
	    err = isInCurve(&ctx->cont, u1point);
	    if (err) {
		err = SUP_ERR_PARAM;
		goto done;
	    }
	    be2le(secretB,(LPBYTE)_2fkc->betta.v,SECRET_KEY_LEN);
	    err = FKCCreateEKE (&ctx->cont, u1point, secretB, chal->id, u2point);
	    memset(secretB,0,SECRET_KEY_LEN);
	    if (err) {
		err = SUP_ERR_CANCEL;
		goto done;
	    }
	    makePointFromBlob(_2csp->u2.x, _2csp->u2.y, u2point);

	    err = RDR_ERR_BLOCK;
	}
	break;
#endif /*_DEBUG*/
    case TRECc_first:
	{
	    BYTE u1point [PUBLICBLOBLEN];
	    BYTE u2point [PUBLICBLOBLEN];
	    const TRdrFkcEKEChallengeFirst2fkc * _2fkc;
	    TRdrFkcEKEChallengeFirst2csp * _2csp;
	    
	    _2fkc = CONSTP2CH(TRdrFkcEKEChallengeFirst2fkc, chal->toFolder);
	    _2csp = P2CH(TRdrFkcEKEChallengeFirst2csp, chal->fromFolder);

	    if (_2fkc->IsNewTr == FKC_TRANSACTION_IS_NEW) {
		ctx->cont.curmask = FKC_TRANS_SET_ZERO;
		ctx->cont.curtrid = _2fkc->TrId;
	    } else {
		if (ctx->cont.curtrid) {
		    if (ctx->cont.curtrid != _2fkc->TrId) {
			err = RDR_ERR_FKC_TRANSACTION;
			goto done;
		    }
		}
	    }
    
	    if( !ctx->auth && (chal->id != TRECi_syncro)) {
		err = RDR_ERR_FKC_NEED_CONT_AUTH;
		goto done;
	    }

	    if (ctx->cont.lpEKEop) eke_cont_release (ctx->cont.lpEKEop);
	    eke_cont_init(&(ctx->cont.lpEKEop));

	    ctx->cont.lpEKEop->curChalClass = TRECc_first;
	    ctx->cont.lpEKEop->curChalID = chal->id;

	    makePublicBlob(&ctx->cont,u1point,(LPBYTE)_2fkc->u1.x, (LPBYTE)_2fkc->u1.y);
	    err = isInCurve(&ctx->cont, u1point);
	    if (err) {
		err = SUP_ERR_PARAM;
		goto done;
	    }
	    err = FKCCreateEKE (&ctx->cont, u1point, NULL, chal->id, u2point);
	    if (err) {
		err = SUP_ERR_CANCEL;
		goto done;
	    }
	    makePointFromBlob(_2csp->u2.x,_2csp->u2.y,u2point);

	    err = RDR_ERR_BLOCK;
	}

	break;
    case TRECc_second:
	if (!ctx->cont.lpEKEop||
	    (ctx->cont.lpEKEop->curChalClass!=TRECc_first)||
	    ((int)ctx->cont.lpEKEop->curChalID!=chal->id)) 
	{
	    err = SUP_ERR_PARAM;
	    goto done;
	}

	switch(chal->id) 
	{
	case TRECi_syncro:
	    {
		DWORD s1;
		BYTE tempsync [SECRET_KEY_LEN];
		const TRdrFkcEKEChallengeReadSyncro2fkc * _2fkc;
		TRdrFkcEKEChallengeReadSyncro2csp * _2csp;
		
		if ( ctx->cont.C.c_seqfls && ctx->cont.C.c_fls) 
		{
		    ctx->cont.C.c_seqfls--;
		    ctx->cont.C.c_fls--;
		} else {
		    err = RDR_ERR_PASSWD_LOCKED;
		    goto doneErr;
		}
			    
		_2fkc = CONSTP2CH(TRdrFkcEKEChallengeReadSyncro2fkc, chal->toFolder);
		_2csp = P2CH(TRdrFkcEKEChallengeReadSyncro2csp, chal->fromFolder);

		if (ctx->cont.curtrid) {
		    if (ctx->cont.curtrid != _2fkc->TrId) {
			err = RDR_ERR_FKC_TRANSACTION;
			goto done;
		    }
		}

		s1 = makeSygma2LE(_2fkc->uiS1);
		memcpy(tempsync, ctx->cont.syncro, SECRET_KEY_LEN);

		err = FKCEKEEncrypt(ctx->cont.lpEKEop, CRYPT_MODE_EKEXOR, 
				    TRUE, tempsync, SECRET_KEY_LEN);
		if(err) {
		    err = RDR_ERR_INVALID_PASSWD_FORMAT;
		    memset(tempsync, 0, SECRET_KEY_LEN);
		    goto doneErr;
		}
		memset(tempsync, 0, 2*sizeof(DWORD));

		err = FKCCreateEKEVerify(chal->id,&ctx->cont,tempsync,ctx->names.RealName, ctx->names.FriendlyName);
		if(err) {
		    memset(tempsync, 0, SECRET_KEY_LEN);
		    goto doneErr;
		}
    
		err = FKCVerifyEKE(ctx->cont.lpEKEop,s1);
		if (err!=SUP_ERR_NO) {
		    memset(tempsync, 0, SECRET_KEY_LEN);
		    goto doneErr;
		}

		_2csp->uiS2 = makeSygma2BE((USHORT)ctx->cont.lpEKEop->Verify_B);
		be2le(_2csp->u3.v,tempsync+8,24);
		memset(tempsync, 0, SECRET_KEY_LEN);
		ctx->cont.C.c_fls++;
		ctx->cont.C.c_seqfls = C_SEQ_FALSE;
		ctx->auth = TRUE;
	    }
	    break;
	case TRECi_Qfkc:
	    {
		const TRdrFkcEKEChallengeReadQFKC2fkc * _2fkc;
		TRdrFkcEKEChallengeReadQFKC2csp * _2csp;
		LPBYTE tempqfkc = NULL;

		if( !ctx->auth ) {
		    err = RDR_ERR_FKC_NEED_CONT_AUTH;
		    goto done;
		}
		ctx->auth = FALSE;

		_2csp = P2CH(TRdrFkcEKEChallengeReadQFKC2csp, chal->fromFolder);
		_2fkc = CONSTP2CH(TRdrFkcEKEChallengeReadQFKC2fkc, chal->toFolder);

		if (ctx->cont.curtrid) {
		    if (ctx->cont.curtrid != _2fkc->TrId) {
			err = RDR_ERR_FKC_TRANSACTION;
			goto done;
		    }
		}

		if (ctx->cont.pbPublicKeyBlob) free (ctx->cont.pbPublicKeyBlob);
		ctx->cont.pbPublicKeyBlob = NULL;

		err = CreatePublicKeyBlob(ctx->cont.hKeyPair, &ctx->cont.dwPubBlobLen, 
		    &ctx->cont.pbPublicKeyBlob);
		if(err) {
		    goto doneErr;
		}
		tempqfkc = malloc(ctx->cont.dwPubBlobLen);
		memcpy(tempqfkc, ctx->cont.pbPublicKeyBlob, ctx->cont.dwPubBlobLen);

		err = FKCEKEEncrypt(ctx->cont.lpEKEop, CRYPT_MODE_EKEECADD, 
				    ECC_PLUS, tempqfkc, ctx->cont.dwPubBlobLen);
		if(err) {
		    memset(tempqfkc, 0, ctx->cont.dwPubBlobLen);
		    free (tempqfkc);
		    goto doneErr;
		}

		makePointFromBlob(_2csp->u3.x, _2csp->u3.y, tempqfkc);
		memset (tempqfkc, 0, ctx->cont.dwPubBlobLen);
		free (tempqfkc);
	    }
	    break;
	}
	if (ctx->cont.lpEKEop) eke_cont_release (ctx->cont.lpEKEop);
	ctx->cont.lpEKEop = NULL;
	err = SUP_ERR_NO;
	ctx->cont.C.c_eke--;
	break;
    }

done:
doneErr:
    if (err && err != RDR_ERR_BLOCK) {
	switch (err) {
	    case RDR_ERR_INVALID_PASSWD_FORMAT:
	    case RDR_ERR_FKC_NEED_ROOT_AUTH:
	    case RDR_ERR_FKC_NEED_CONT_AUTH:
	    case SUP_ERR_PARAM:
	    case RDR_ERR_FKC_TRANSACTION:
	    case RDR_ERR_FKC_OPLIMIT_REACHED:
		break;
	    case RDR_ERR_INVALID_PASSWD:
		if (!ctx->cont.C.c_fls || !ctx->cont.C.c_seqfls) {
		    err = RDR_ERR_PASSWD_LOCKED;
		}
		break;
	    default:
		err = SUP_ERR_CANCEL;
	}
	if (ctx->cont.lpEKEop) eke_cont_release (ctx->cont.lpEKEop);
	ctx->cont.lpEKEop = NULL;
    }
    fkchdimg_infofile_write(ctx);
    return err;
}
