#include "fkchdimgprj.h"

static DWORD makeDWORD2BE(DWORD be) 
{
    return ((be&0xFF000000)>>24)|((be&0xFF0000)>>8)|((be&0xFF00)<<8)|((be&0xFF)<<24);
}

static void makeCountersUEC(TRdrFkcInfoCounters *dest, DWORD seqfls)
{
    (*dest)[TRIFc_EKE] = makeDWORD2BE((DWORD)10000000);
    (*dest)[TRIFc_Sign] = makeDWORD2BE((DWORD)10000000);
    (*dest)[TRIFc_DH] = makeDWORD2BE((DWORD)10000000);
    (*dest)[TRIFc_fail] = makeDWORD2BE((DWORD)100);
    (*dest)[TRIFc_cfail] = makeDWORD2BE(seqfls);
}

TSupErr uechdimg_get_param( TSupSysContext *context, TSupSysInfo *info )
{
    TRdrFkcFolderEnumParam paramID;
    TRdrFolderParamValue * pv;
    TSupErr code = SUP_ERR_NO;
    TUECHDImgContext *ctx = (TUECHDImgContext*)context;

    SUPSYS_PRE_CONTEXT( context, TUECHDImgContext );
    pv = ((TReaderInfoFolderParamGet *)info)->paramValue;

    paramID = ((TReaderInfoFolderParamGet *)info)->paramID;
    switch (paramID)
    {
    case TCEP_counters:
	{
	    long rem = 0;
	    TRdrFkcFolderCountersParam *value = P2CH(TRdrFkcFolderCountersParam, pv);
	    code = support_registry_get_long (ctx->pin_count_path, &rem);
	    if (code) {
		code = support_registry_put_long(ctx->pin_count_path, MAX_PIN_TRIES);
		if (code)
		    return code;
		code = support_registry_get_long (ctx->pin_count_path, &rem);
		if (code)
		    return code;
	    }
	    makeCountersUEC(&value->initCounters, (DWORD)rem);
	}
	break;
    case TCEP_newKeys:
	{
	    TRdrFkcFolderNewKeysParam *value = P2CH(TRdrFkcFolderNewKeysParam,pv);
	    value->bEnableInitKeys = TRUE;
	    value->bEnableSetKeys = FALSE;
	}
	break;
    case TCEP_disablePassword:
	{
	    TRdrFkcFolderDisablePasswordParam *value = P2CH(TRdrFkcFolderDisablePasswordParam,pv);
	    long need = 0;
	    code = support_registry_get_long (ctx->pin_need_path, &need);
	    if (code) {
		need = 0;
		support_registry_put_long(ctx->pin_need_path, need);
	    }
	    value->bDisablePassword =  (need == 1) ? FALSE : TRUE;
	}
	break;
    default:
	return SUP_ERR_PARAM;
    }

    return code;
}
