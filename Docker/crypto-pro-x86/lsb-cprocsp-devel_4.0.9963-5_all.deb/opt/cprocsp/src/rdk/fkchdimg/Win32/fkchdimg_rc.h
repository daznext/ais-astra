//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by fkchdimg_rc.rc
//
#define IDI_FKCHDIMG                    105
#define IDS_FKCHDIMG_NAME               0x1000
#define IDS_FKCHDIMG_NICKNAME           0x1001
#define IDS_GROUP_NICKNAME              0x1004
#define IDS_GROUP_NAME                  0x1005
#define IDS_FKCHDIMG_INSERT_TEXT        0x1300
#define IDS_FKCHDIMG_CARRIER_TYPE       0x1302
#define IDI_UECHDIMG                    0x2000
#define IDS_UECHDIMG_NAME               0x2000
#define IDS_UECHDIMG_NICKNAME           0x2001
#define IDS_UECHDIMG_CARRIER_TYPE       0x2302
#define IDI_UECHDIMG2                   0x3000
#define IDS_UECHDIMG2_NAME              0x3000
#define IDS_UECHDIMG2_NICKNAME          0x3001
#define IDS_UECHDIMG2_CARRIER_TYPE      0x3302


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
