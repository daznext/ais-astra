static void __dummy_func()
{
}
