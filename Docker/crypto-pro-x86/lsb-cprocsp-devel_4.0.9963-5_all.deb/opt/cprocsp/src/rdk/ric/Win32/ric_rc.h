//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ric_rc.rc
//
#define IDS_BASE_FSIZE_TITLE            1
#define IDS_BASE_FSIZE_SUBTITLE         2
#define IDD_SIZE                        107
#define IDD_SIZE_WIZARD                 108
#define IDC_EDIT_FILE1                  1001
#define IDC_EDIT_FILE2                  1002
#define IDC_EDIT_FILE6                  1003
#define IDC_RESERVE                     1004
#define IDC_ATR                         1007
#define IDC_MASK                        1008
#define IDC_APPLICATION                 1009
#define IDC_STATIC_FILE1                1010
#define IDC_STATIC_FILE2                1011
#define IDC_STATIC_FILE6                1012
#define IDC_STATIC_FILE1_REM            1013
#define IDC_STATIC_FILE2_REM            1014
#define IDC_STATIC_FILE6_REM            1015
#define IDC_WINLOGON                    1016
#define IDC_STATIC_APPLICATION          1018
#define IDI_RIC                         4096
#define IDS_RIC_NAME                    0x1000
#define IDS_RIC_NICKNAME                0x1001
#define IDS_RIC_CARRIER_TYPE            0x1302
#define IDI_OSCAR                       0x2000
#define IDS_OSCAR_NAME                  0x2000
#define IDS_OSCAR_NICKNAME              0x2001
#define IDS_OSCAR_CARRIER_TYPE          0x2302
#define IDS_OSCAR2_NAME                 0x3000
#define IDS_OSCAR2_NICKNAME             0x3001
#define IDS_OSCAR2_CARRIER_TYPE         0x3302
#define IDI_TRUST                       0x4000
#define IDS_TRUSTD_NAME                 0x4000
#define IDS_TRUSTD_NICKNAME             0x4001
#define IDS_TRUSTD_CARRIER_TYPE         0x4302
#define IDS_TRUST_NAME                  0x5000
#define IDS_TRUST_NICKNAME              0x5001
#define IDS_TRUST_CARRIER_TYPE          0x5302
#define IDS_TRUSTS_NAME                 0x6000
#define IDS_TRUSTS_NICKNAME             0x6001
#define IDS_TRUSTS_CARRIER_TYPE         0x6302

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
